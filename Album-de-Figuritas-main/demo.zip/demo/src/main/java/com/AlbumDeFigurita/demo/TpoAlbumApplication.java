package com.AlbumDeFigurita.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TpoAlbumApplication {

	public static void main(String[] args) {
		SpringApplication.run(TpoAlbumApplication.class, args);
	}

}
